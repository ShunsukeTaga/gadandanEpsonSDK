//
//  ViewController.h
//  ePOS2_Composite
//
//

#import <UIKit/UIKit.h>

#import "ePOS2.h"

@interface ViewController : UIViewController
{    
    
}

@end

