#import "CommandViewController.h"
#import "ShowMsg.h"

@interface CommandViewController()<Epos2CATDirectIOCommandReplyDelegate>
@end

@implementation CommandViewController

- (id)initWithCoder:(NSCoder *)aDecoder
{
    self = [super initWithCoder:aDecoder];
    if (self) {
        cat_ = nil;
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];

    serviceList_ = [[PickerTableView alloc] init];
    NSMutableArray *items = [[NSMutableArray alloc] init];
    [items addObject:NSLocalizedString(@"credit", @"")];
    [items addObject:NSLocalizedString(@"debit", @"")];
    [items addObject:NSLocalizedString(@"unionpay", @"")];
    [items addObject:NSLocalizedString(@"edy", @"")];
    [items addObject:NSLocalizedString(@"id", @"")];
    [items addObject:NSLocalizedString(@"nanaco", @"")];
    [items addObject:NSLocalizedString(@"quicpay", @"")];
    [items addObject:NSLocalizedString(@"suica", @"")];
    [items addObject:NSLocalizedString(@"waon", @"")];
    [items addObject:NSLocalizedString(@"point", @"")];
    [items addObject:NSLocalizedString(@"common", @"")];

    [serviceList_ setItemList:items];
    [_buttonService setTitle:[serviceList_ getItem:0] forState:UIControlStateNormal];
    serviceList_.delegate = self;
    service_ = EPOS2_SERVICE_CREDIT;

    _textDirectIOCommand.keyboardType = UIKeyboardTypeNumberPad;
    _textDirectIOData.keyboardType = UIKeyboardTypeNumberPad;

    [self setDoneToolbar];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    
    [self setEventDelegate];
}

- (void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:animated];
    
    [self releaseEventDelegate];
}

- (void)setDoneToolbar
{
    UIToolbar *doneToolbar = [[UIToolbar alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 44)];
    doneToolbar.barStyle = UIBarStyleBlackTranslucent;
    
    [doneToolbar sizeToFit];
    UIBarButtonItem *space = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:self action:nil];
    UIBarButtonItem *doneButton = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone target:self action:@selector(doneCAT:)];
    
    NSMutableArray *items = [NSMutableArray arrayWithObjects:space, doneButton, nil];
    [doneToolbar setItems:items animated:YES];
    _textDirectIOCommand.inputAccessoryView = doneToolbar;
    _textDirectIOData.inputAccessoryView = doneToolbar;
    _textDirectIOString.inputAccessoryView = doneToolbar;
}

- (void)doneCAT:(id)sender
{
    [_textDirectIOCommand resignFirstResponder];
    [_textDirectIOData resignFirstResponder];
    [_textDirectIOString resignFirstResponder];
}

- (void)setEventDelegate
{
    [super setEventDelegate];
    
    if(cat_) {
        [cat_ setDirectIOCommandReplyEventDelegate:self];
    }
}

- (void)releaseEventDelegate
{
    [super releaseEventDelegate];
    
    if(cat_) {
        [cat_ setDirectIOCommandReplyEventDelegate:nil];
    }
}

- (IBAction)eventButtonDidPush:(id)sender
{
    [serviceList_ show];
}

- (IBAction)onSendDirectIOCommand:(id)sender {
    int result = EPOS2_SUCCESS;
    long command = [_textDirectIOCommand.text intValue];
    long data = [_textDirectIOData.text intValue];
    
    if(cat_ == nil) {
        return;
    }
    
    [cat_ sendDirectIOCommand:command data:data string:_textDirectIOString.text service:service_];
    if (result != EPOS2_SUCCESS) {
        [ShowMsg showErrorEpos:result method:@"sendDirectIOCommand"];
        return;
    }
}

- (void) onCATDirectIOCommandReply:(Epos2CAT *)catObj code:(int)code command:(long)command data:(long)data string:(NSString *)string sequence:(long)sequence service:(int)service result:(Epos2CATDirectIOResult *)result
{
    int oposCode = 0;
    if(code == EPOS2_CAT_CODE_ERR_OPOSCODE) {
        oposCode = [catObj getOposErrorCode];
        [ShowMsg showResult:code oposCode:oposCode];
    } else {
        [ShowMsg showResult:code];
    }
    
    self.textCAT.text = [self.textCAT.text stringByAppendingString:[NSString stringWithFormat:@"OnDirectIOCommandReply:\n"]];

    self.textCAT.text = [self.textCAT.text stringByAppendingString:[NSString stringWithFormat:@"  command:%ld\n", command]];
    self.textCAT.text = [self.textCAT.text stringByAppendingString:[NSString stringWithFormat:@"  data:%ld\n", data]];
    self.textCAT.text = [self.textCAT.text stringByAppendingString:[NSString stringWithFormat:@"  string:%@\n", string]];
    if(result != nil) {
        self.textCAT.text = [self.textCAT.text stringByAppendingString:[self makeDirectIOResultMessage:result]];
    }
    [self scrollText];
}

- (NSString *) makeDirectIOResultMessage:(Epos2CATDirectIOResult *)result
{
    NSMutableString *resultMsg = [[NSMutableString alloc]initWithString:@""];

    [resultMsg appendString:[NSString stringWithFormat:@"  AccountNumber:%@\n", [result getAccountNumber]]];
    [resultMsg appendString:[NSString stringWithFormat:@"  SettledAmount:%ld\n", [result getSettledAmount]]];
    [resultMsg appendString:[NSString stringWithFormat:@"  SlipNumber:%@\n", [result getSlipNumber]]];
    [resultMsg appendString:[NSString stringWithFormat:@"  TransactionNumber:%@\n", [result getTransactionNumber]]];
    [resultMsg appendString:[NSString stringWithFormat:@"  PaymentCondition:%@\n", [self getPaymentConditionText:[result getPaymentCondition]]]];
    [resultMsg appendString:[NSString stringWithFormat:@"  Balance:%ld\n", [result getBalance]]];
    [resultMsg appendString:[NSString stringWithFormat:@"  AdditionalSecurityInformation:%@\n", [result getAdditionalSecurityInformation]]];

    return resultMsg;
}

- (void)onSelectPickerItem:(NSInteger)position obj:(id)obj
{
    if (obj == serviceList_) {
        [_buttonService setTitle:[serviceList_ getItem:position] forState:UIControlStateNormal];
        service_ = (int)serviceList_.selectIndex;
    }
}

- (IBAction)clearCAT:(id)sender
{
    self.textCAT.text = @"";
}
@end
