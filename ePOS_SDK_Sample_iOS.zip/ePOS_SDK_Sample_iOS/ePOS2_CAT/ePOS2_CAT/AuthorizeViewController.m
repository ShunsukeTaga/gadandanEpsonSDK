#import "AuthorizeViewController.h"
#import "ShowMsg.h"

#define SEQUENCE_NUM    (0001)

@interface AuthorizeViewController()<Epos2CATAuthorizeSalesDelegate, Epos2CATAuthorizeVoidDelegate, Epos2CATAuthorizeRefundDelegate, Epos2CATAuthorizeCompletionDelegate,
    Epos2CATAccessDailyLogDelegate>
@end

@implementation AuthorizeViewController

- (id)initWithCoder:(NSCoder *)aDecoder
{
    self = [super initWithCoder:aDecoder];
    if (self) {
        cat_ = nil;
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    serviceList_ = [[PickerTableView alloc] init];
    NSMutableArray *items = [[NSMutableArray alloc] init];
    [items addObject:NSLocalizedString(@"credit", @"")];
    [items addObject:NSLocalizedString(@"debit", @"")];
    [items addObject:NSLocalizedString(@"unionpay", @"")];
    [items addObject:NSLocalizedString(@"edy", @"")];
    [items addObject:NSLocalizedString(@"id", @"")];
    [items addObject:NSLocalizedString(@"nanaco", @"")];
    [items addObject:NSLocalizedString(@"quicpay", @"")];
    [items addObject:NSLocalizedString(@"suica", @"")];
    [items addObject:NSLocalizedString(@"waon", @"")];

    [serviceList_ setItemList:items];
    [_buttonService setTitle:[serviceList_ getItem:0] forState:UIControlStateNormal];
    serviceList_.delegate = self;
    service_ = EPOS2_SERVICE_CREDIT;
    
    authorizeList_ = [[PickerTableView alloc] init];
    items = [[NSMutableArray alloc ] init];
    [items addObject:NSLocalizedString(@"authorize_sales", @"")];
    [items addObject:NSLocalizedString(@"authorize_void", @"")];
    [items addObject:NSLocalizedString(@"authorize_refund", @"")];
    [items addObject:NSLocalizedString(@"authorize_completion", @"")];
    
    [authorizeList_ setItemList:items];
    [_buttonAuthorize setTitle:[authorizeList_ getItem:0] forState:UIControlStateNormal];
    authorizeList_.delegate = self;
    authorize_ = 0;

    _textTotalAmount.keyboardType = UIKeyboardTypeNumberPad;

    [self setDoneToolbar];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];

    [self setEventDelegate];
}

- (void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:animated];

    [self releaseEventDelegate];
}

- (void)setEventDelegate
{
    [super setEventDelegate];

    if(cat_) {
        [cat_ setAuthorizeSalesEventDelegate:self];
        [cat_ setAuthorizeVoidEventDelegate:self];
        [cat_ setAuthorizeRefundEventDelegate:self];
        [cat_ setAuthorizeCompletionEventDelegate:self];
        [cat_ setAccessDailyLogEventDelegate:self];
    }
}

- (void)releaseEventDelegate
{
    [super releaseEventDelegate];

    if(cat_) {
        [cat_ setAuthorizeSalesEventDelegate:nil];
        [cat_ setAuthorizeVoidEventDelegate:nil];
        [cat_ setAuthorizeRefundEventDelegate:nil];
        [cat_ setAuthorizeCompletionEventDelegate:nil];
        [cat_ setAccessDailyLogEventDelegate:nil];
    }
}

- (void)setDoneToolbar
{
    UIToolbar *doneToolbar = [[UIToolbar alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 44)];
    doneToolbar.barStyle = UIBarStyleBlackTranslucent;
    
    [doneToolbar sizeToFit];
    UIBarButtonItem *space = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:self action:nil];
    UIBarButtonItem *doneButton = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone target:self action:@selector(doneCAT:)];
    
    NSMutableArray *items = [NSMutableArray arrayWithObjects:space, doneButton, nil];
    [doneToolbar setItems:items animated:YES];
    _textTotalAmount.inputAccessoryView = doneToolbar;
}

- (void)doneCAT:(id)sender
{
    [_textTotalAmount resignFirstResponder];
}

- (IBAction)eventButtonDidPush:(id)sender
{
    switch (((UIView *)sender).tag) {
        case 1:
            [serviceList_ show];
            break;
        case 2:
            [authorizeList_ show];
            break;
        default:
            break;
    }
}

- (IBAction)onCrealance:(id)sender
{
    int result = EPOS2_SUCCESS;
    long totalAmount = [_textTotalAmount.text intValue];
    
    if(cat_ == nil) {
        return;
    }
    
    switch (authorize_) {
        case 0:// authorizeSalse
            result = [cat_ authorizeSales:service_ totalAmount:totalAmount sequence:SEQUENCE_NUM];
            break;
        case 1:// authorizeVoid
            result = [cat_ authorizeVoid:service_ totalAmount:totalAmount sequence:SEQUENCE_NUM];
            break;
        case 2:// authorizeRefund
            result = [cat_ authorizeRefund:service_ totalAmount:totalAmount sequence:SEQUENCE_NUM];
            break;
        case 3:// authorizeComplation
            result = [cat_ authorizeCompletion:service_ totalAmount:totalAmount sequence:SEQUENCE_NUM];
            break;
        default:
            break;
    }
    if (result != EPOS2_SUCCESS) {
        [ShowMsg showErrorEpos:result method:[authorizeList_ getItem:authorize_]];
        return;
    }
}

- (IBAction)onAccessDailyLog:(id)sender {
    int result = EPOS2_SUCCESS;
    
    if(cat_ == nil) {
        return;
    }

    result = [cat_ accessDailyLog:service_ sequence:SEQUENCE_NUM];
    if (result != EPOS2_SUCCESS) {
        [ShowMsg showErrorEpos:result method:@"accessDailyLog"];
        return;
    }
}

- (void) onCATAuthorizeSales:(Epos2CAT *)catObj code:(int)code sequence:(long)sequence service:(int)service result:(Epos2CATAuthorizeResult *)result
{
    int oposCode = 0;
    if(code == EPOS2_CAT_CODE_ERR_OPOSCODE) {
        oposCode = [catObj getOposErrorCode];
        [ShowMsg showResult:code oposCode:oposCode];
    } else {
        [ShowMsg showResult:code];
    }

    if(result != nil) {
        self.textCAT.text = [self.textCAT.text stringByAppendingString:[NSString stringWithFormat:@"OnAuthorizeSales:\n"]];
        self.textCAT.text = [self.textCAT.text stringByAppendingString:[self makeAuthorizeResultMessage:result]];
    }
    [self scrollText];
}

- (void) onCATAuthorizeVoid:(Epos2CAT *)catObj code:(int)code sequence:(long)sequence service:(int)service result:(Epos2CATAuthorizeResult *)result
{
    int oposCode = 0;
    if(code == EPOS2_CAT_CODE_ERR_OPOSCODE) {
        oposCode = [catObj getOposErrorCode];
        [ShowMsg showResult:code oposCode:oposCode];
    } else {
        [ShowMsg showResult:code];
    }

    if(result != nil) {
        self.textCAT.text = [self.textCAT.text stringByAppendingString:[NSString stringWithFormat:@"OnAuthorizeVoid:\n"]];
        self.textCAT.text = [self.textCAT.text stringByAppendingString:[self makeAuthorizeResultMessage:result]];
    }
    [self scrollText];
}

- (void) onCATAuthorizeRefund:(Epos2CAT *)catObj code:(int)code sequence:(long)sequence service:(int)service result:(Epos2CATAuthorizeResult *)result
{
    int oposCode = 0;
    if(code == EPOS2_CAT_CODE_ERR_OPOSCODE) {
        oposCode = [catObj getOposErrorCode];
        [ShowMsg showResult:code oposCode:oposCode];
    } else {
        [ShowMsg showResult:code];
    }

    if(result != nil) {
        self.textCAT.text = [self.textCAT.text stringByAppendingString:[NSString stringWithFormat:@"OnAuthorizeRefund:\n"]];
        self.textCAT.text = [self.textCAT.text stringByAppendingString:[self makeAuthorizeResultMessage:result]];
    }
    [self scrollText];
}

- (void) onCATAuthorizeCompletion:(Epos2CAT *)catObj code:(int)code sequence:(long)sequence service:(int)service result:(Epos2CATAuthorizeResult *)result
{
    int oposCode = 0;
    if(code == EPOS2_CAT_CODE_ERR_OPOSCODE) {
        oposCode = [catObj getOposErrorCode];
        [ShowMsg showResult:code oposCode:oposCode];
    } else {
        [ShowMsg showResult:code];
    }

    if(result != nil) {
        self.textCAT.text = [self.textCAT.text stringByAppendingString:[NSString stringWithFormat:@"OnAuthorizeCompletion:\n"]];
        self.textCAT.text = [self.textCAT.text stringByAppendingString:[self makeAuthorizeResultMessage:result]];
    }
    [self scrollText];
}

- (void) onCATAccessDailyLog:(Epos2CAT *)catObj code:(int)code sequence:(long)sequence service:(int)service dailyLog:(NSArray *)dailyLog
{
    int oposCode = 0;
    if(code == EPOS2_CAT_CODE_ERR_OPOSCODE) {
        oposCode = [catObj getOposErrorCode];
        [ShowMsg showResult:code oposCode:oposCode];
    } else {
        [ShowMsg showResult:code];
    }

    if(dailyLog != nil) {
        self.textCAT.text = [self.textCAT.text stringByAppendingString:[NSString stringWithFormat:@"OnAccessDailyLog:\n"]];
        for(Epos2CATDailyLog *log in dailyLog) {
            self.textCAT.text = [self.textCAT.text stringByAppendingString:[NSString stringWithFormat:@"  Kid:%@\n", [log getKid]]];
            self.textCAT.text = [self.textCAT.text stringByAppendingString:[NSString stringWithFormat:@"  SalesCount:%lld\n", [log getSalesCount]]];
            self.textCAT.text = [self.textCAT.text stringByAppendingString:[NSString stringWithFormat:@"  SalesAmount:%lld\n", [log getSalesAmount]]];
            self.textCAT.text = [self.textCAT.text stringByAppendingString:[NSString stringWithFormat:@"  VoidCount:%lld\n", [log getVoidCount]]];
            self.textCAT.text = [self.textCAT.text stringByAppendingString:[NSString stringWithFormat:@"  VoidAmount:%lld\n", [log getVoidAmount]]];
        }
    }
    [self scrollText];
}

- (NSString *) makeAuthorizeResultMessage:(Epos2CATAuthorizeResult *)result
{
    NSMutableString *resultMsg = [[NSMutableString alloc]initWithString:@""];
    
    [resultMsg appendString:[NSString stringWithFormat:@"  AccountNumber:%@\n", [result getAccountNumber]]];
    [resultMsg appendString:[NSString stringWithFormat:@"  SettledAmount:%ld\n", [result getSettledAmount]]];
    [resultMsg appendString:[NSString stringWithFormat:@"  SlipNumber:%@\n", [result getSlipNumber]]];
    [resultMsg appendString:[NSString stringWithFormat:@"  Kid:%@\n", [result getKid]]];
    [resultMsg appendString:[NSString stringWithFormat:@"  ApprovalCode:%@\n", [result getApprovalCode]]];
    [resultMsg appendString:[NSString stringWithFormat:@"  TransactionNumber:%@\n", [result getTransactionNumber]]];
    [resultMsg appendString:[NSString stringWithFormat:@"  PaymentCondition:%@\n", [self getPaymentConditionText:[result getPaymentCondition]]]];
    [resultMsg appendString:[NSString stringWithFormat:@"  VoidSlipNumber:%@\n", [result getVoidSlipNumber]]];
    [resultMsg appendString:[NSString stringWithFormat:@"  Balance:%ld\n", [result getBalance]]];
    
    return resultMsg;
}

- (void)onSelectPickerItem:(NSInteger)position obj:(id)obj
{
    if (obj == serviceList_) {
        [_buttonService setTitle:[serviceList_ getItem:position] forState:UIControlStateNormal];
        service_ = (int)serviceList_.selectIndex;

    }
    else if (obj == authorizeList_) {
        [_buttonAuthorize setTitle:[authorizeList_ getItem:position] forState:UIControlStateNormal];
        authorize_ = (int)authorizeList_.selectIndex;
    }
    else {
        ; //do nothing
    }
}

- (IBAction)clearCAT:(id)sender
{
    self.textCAT.text = @"";
}
@end
