#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>

@interface MainTableViewController : UITableViewController<CLLocationManagerDelegate>

@end
