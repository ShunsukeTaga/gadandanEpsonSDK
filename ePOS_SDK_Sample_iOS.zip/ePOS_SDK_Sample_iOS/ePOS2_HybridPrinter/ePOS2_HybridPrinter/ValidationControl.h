//
//  ValidationControl.h
//  ePOS2_HybridPrinter
//

#ifndef ValidationControl_h
#define ValidationControl_h
#import <Foundation/Foundation.h>
#import "SlipControl.h"

@interface ValidationControl : SlipControl
{
}
@end

#endif /* ValidationControl_h */
