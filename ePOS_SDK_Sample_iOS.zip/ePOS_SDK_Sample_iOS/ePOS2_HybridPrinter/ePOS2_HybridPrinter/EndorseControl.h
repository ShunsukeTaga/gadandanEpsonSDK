//
//  EndorseControl.h
//  ePOS2_HybridPrinter
//

#ifndef EndorseControl_h
#define EndorseControl_h
#import <Foundation/Foundation.h>
#import "SlipControl.h"

@interface EndorseControl : SlipControl
{
}
@end

#endif /* EndorseControl_h */
