//
//  ReceiptControl.h
//  ePOS2_HybridPrinter
//

#ifndef ReceiptControl_h
#define ReceiptControl_h
#import <Foundation/Foundation.h>
#import "DeviceControl.h"

@interface ReceiptControl : DeviceControl
{
}
@end

#endif /* ReceiptControl_h */
