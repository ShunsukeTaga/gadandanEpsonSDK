//
//  SlipControl.h
//  ePOS2_HybridPrinter
//

#ifndef SlipControl_h
#define SlipControl_h
#import <Foundation/Foundation.h>
#import "DeviceControl.h"

@interface SlipControl : DeviceControl
{
}
@end


#endif /* SlipControl_h */
