#import "ePOS2.h"

#import <UIKit/UIKit.h>
#import "CashChangerViewController.h"

@interface DrawerViewController : CashChangerViewController
@property (weak, nonatomic) IBOutlet UIButton *buttonClear;
@end
