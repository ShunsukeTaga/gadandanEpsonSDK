#import "ePOS2.h"

#import <UIKit/UIKit.h>
#import "CashChangerViewController.h"

@interface CashCountViewController : CashChangerViewController

@property (weak, nonatomic) IBOutlet UIButton *buttonClear;
@end
